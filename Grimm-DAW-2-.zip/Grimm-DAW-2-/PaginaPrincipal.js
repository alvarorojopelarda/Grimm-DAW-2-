

function nuevoWesen() {
  var nombre = document.getElementById('nombre').value;
  var imagen = document.getElementById('imagen').value;
  var tipo = document.getElementById('tipo').value;
  var peligrosidad = document.getElementById('peligrosidad').value;
  var descripcion = document.getElementById('descripcion').value;
  var notas = document.getElementById('notas').value;

  var nuevoWesen = {
      id: nombre,
      Nombre: nombre,
      Foto: imagen,
      Tipo: tipo,
      Peligrosidad: peligrosidad,
      Descripcion: descripcion,
      Notas: notas
  };

  wesenInfo.push(nuevoWesen);

  var newRow = document.createElement('tr');
  newRow.id = nuevoWesen.id;

  var nameCell = document.createElement('td');
  nameCell.textContent = nombre;
  nameCell.onclick = function () {
    console.log(nuevoWesen.id);
      mostrarInformacion(nuevoWesen.id);
  };
  console.log(nameCell.onclick);
  var imageCell = document.createElement('td');

  var wesenImage = document.createElement('img');
  wesenImage.style.width = "140px";
  wesenImage.style.height = "130px";
  wesenImage.src = imagen;
  wesenImage.alt = nombre;
  wesenImage.onclick = function () {
      mostrarInformacion(nuevoWesen.id);
  };
  imageCell.appendChild(wesenImage);

  newRow.appendChild(nameCell);
  newRow.appendChild(imageCell);

  var tableBody = document.querySelector('.tableWesenCompleted tbody');
  tableBody.appendChild(newRow);

  document.getElementById('nombre').value = '';
  document.getElementById('imagen').value = '';
  document.getElementById('tipo').value = '';
  document.getElementById('peligrosidad').value = '';
  document.getElementById('descripcion').value = '';
  document.getElementById('notas').value = '';

  mostrarInformacion(nuevoWesen.id);
}




 







































































/*function agregarWesen() {
    // Obtener los valores ingresados en el formulario

    var nombre = document.getElementById("nombre").value;
    var imagen = document.getElementById("imagen").value;
    wesenTable = document.getElementById("tableWesenCompleted");

    // Verificar que los campos no estén vacíos
    if (nombre.trim() === '' || imagen.trim() === '') {
        alert("Por favor, complete los campos Nombre e Imagen.");
        return;
    }

    // Crear un nuevo objeto Wesen con los valores ingresados
    var nuevoWesen = {
        id: nombre.replace(/\s/g, ''),
        Nombre: nombre,
        Foto: imagen
    };

    // Agregar el nuevo Wesen al array
    // wesenTable.push(nuevoWesen);
    actualizarWesenInfo(nuevoWesen);
}

// function obtenerWesen(nuevoWesen){

// }

// function agregarWesen() {
//   // Lógica para agregar el nuevo wesen a la lista de wesen existentes
//   const wesen = obtenerWesen(nuevoWesen); // Función para obtener los wesen existentes (puedes implementarla según tus necesidades)
//   wesen.push(wesenInfo);
//   // Actualizar la información de los wesen en la tabla
//   actualizarWesenInfo();
// }

/*function actualizarWesenInfo(nuevoWesen) {
  // Obtener el elemento de la tabla donde se muestra la información de los wesen
  const infoWesen = wesenInfo; //pillamos los wesen
  const tablaWesen = document.querySelector(".tableWesenCompleted");;
  //metrmos el wesen nuevo
//   agregarWesen()
  //mostrar la tabla actualizada

  
  // Obtener los wesen
//   const wesen = obtenerWesen(); // Función para obtener los wesen (puedes implementarla según tus necesidades)
  
  // Limpiar la tabla de wesen
//   tablaWesen.innerHTML = '';
  

//pillar los datos del wesen nuevo (botón)
  // Llenar la tabla con los datos de los wesen
infoWesen.push(nuevoWesen);

    const row = tablaWesen.insertRow();
    row.insertCell(0).textContent = nuevoWesen.id;
    row.insertCell(1).textContent = nuevoWesen.nombre;
    row.insertCell(2).textContent = nuevoWesen.tipo;
    console.log("wesenInfo")
}





// const checkForm = document.getElementById("mostrarFormulario");

// function checkIfFormExists(){
//     if (checkForm){
//         checkForm.addEventListener("click", function () {
// //             agregarWesen
//         });
               
//     }
//     else {
//         console.log("naaaaada  ")
//     }
// }

*/
/*function actualizarWesenInfo(nuevoWesen) {
  // Obtener el elemento de la tabla donde se muestra la información de los wesen
  const infoWesen = wesenInfo; //pillamos los wesen
  const tablaWesen = document.querySelector(".tableWesenCompleted");;
  //metrmos el wesen nuevo
//   agregarWesen()
  //mostrar la tabla actualizada

  
  // Obtener los wesen
//   const wesen = obtenerWesen(); // Función para obtener los wesen (puedes implementarla según tus necesidades)
  
  // Limpiar la tabla de wesen
//   tablaWesen.innerHTML = '';
  

//pillar los datos del wesen nuevo (botón)
  // Llenar la tabla con los datos de los wesen
/*infoWesen.push(nuevoWesen);

    const row = tablaWesen.insertRow();
    row.insertCell(0).textContent = nuevoWesen.id;
    row.insertCell(1).textContent = nuevoWesen.nombre;
    row.insertCell(2).textContent = nuevoWesen.tipo;

console.log("wesenInfo");
*/





       
            
          
          
    


