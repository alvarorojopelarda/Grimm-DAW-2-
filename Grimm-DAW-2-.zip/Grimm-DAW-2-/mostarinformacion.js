
function guardarCambios() {
    var form = document.getElementById('wesenForm');
    var nombreInput = form.querySelector('#nombre');
    var imagenInput = form.querySelector('#imagen');
    var tipoInput = form.querySelector('#tipo');
    var peligrosidadInput = form.querySelector('#peligrosidad');
    var descripcionTextarea = form.querySelector('#descripcion');
    var notasTextarea = form.querySelector('#notas');
    var imagenPreview = form.querySelector('#imagenPreview');

    var nombre = nombreInput.value;
    var imagen = imagenInput.value;
    var tipo = tipoInput.value;
    var peligrosidad = peligrosidadInput.value;
    var descripcion = descripcionTextarea.value;
    var notas = notasTextarea.value;

    var wesen = wesenInfo.find(function (w) {
        return w.Nombre === nombre;
    });

    if (wesen) {
        wesen.Foto = imagen;
        wesen.Tipo = tipo;
        wesen.Peligrosidad = peligrosidad;
        wesen.Descripcion = descripcion;
        wesen.Notas = notas;

       
        imagenPreview.src = imagen;

        nombreInput.value = '';
        imagenInput.value = '';
        tipoInput.value = '';
        peligrosidadInput.value = '';
        descripcionTextarea.value = '';
        notasTextarea.value = '';
    } else {
        alert("Wesen no encontrado");
    }
}

function mostrarInformacion(id) {
    console.log("hola");
    var wesen = wesenInfo.find(function (w) {
        return w.id === id;
    });

    var form = document.getElementById('wesenForm');
    var nombreInput = form.querySelector('#nombre');
    var imagenInput = form.querySelector('#imagen');
    var tipoInput = form.querySelector('#tipo');
    var peligrosidadInput = form.querySelector('#peligrosidad');
    var descripcionTextarea = form.querySelector('#descripcion');
    var notasTextarea = form.querySelector('#notas');
    var imagenPreview = form.querySelector('#imagenPreview');

    nombreInput.value = wesen.Nombre;
    imagenInput.value = wesen.Foto;
    tipoInput.value = wesen.Tipo;
    peligrosidadInput.value = wesen.Peligrosidad;
    descripcionTextarea.value = wesen.Descripcion;
    notasTextarea.value = wesen.Notas;

   
}

var wesenInfo = [
    {
        id: 'ElCucuy',
        Nombre: 'El Cucuy',
        Foto: 'https://static.wikia.nocookie.net/grimm/images/f/fd/305-El_Cucuy.png/revision/latest/scale-to-width-down/150?cb=20131130183201.jpg',
        Tipo: 'Criatura similar al hombre del saco',
        Peligrosidad: 'Alta',
        Descripcion: 'Durante muchos años, El Cucuy ha inspirado leyendas en las culturas de habla hispana sobre un homónimo parecido al hombre del saco que castiga a quienes han hecho mal. El cuento se utiliza especialmente como motivación para que los niños escuchen a sus padres. El Cucuy rara vez se exhibe delante de otros para ocultar su identidad. Se comportan como si fueran justicieros y son conocidos por administrar justicia (o al menos venganza) a quienes la buscan. Sus ataques son muy brutales y su modus operandi típico consiste en cortar agresivamente el cuello de su víctima. No sienten ninguna simpatía por sus víctimas y parecen disfrutar aplicando el castigo fatal. Generalmente se supone que los asesinatos cometidos por El Cucuy los cometen perros salvajes, aunque las personas familiarizadas con los ataques de perros reales (como los veterinarios o Blutbaden ) pueden notar fácilmente la diferencia.',
        Notas: 'Cuando es atacado , El Cucuy obtiene ojos amarillos con escleróticas negras, una boca ancha llena de dientes afilados, orejas puntiagudas y garras largas. Poseen pelo gris en la cabeza y la barbilla y tienen una habilidad inexplicable para escuchar gritos de ayuda a kilómetros de distancia. Son muy fuertes y ágiles en su forma woged; A diferencia de otros Wesen, sus habilidades no parecen disminuir en lo más mínimo con la edad avanzada. El Cucuy puede concentrar sus woge solo en sus ojos y oídos, lo que le permite escuchar a quienes rezan por él sin revelar su verdadera forma.'
    },
    {
        id: 'Drang-Zorn',
        Nombre: 'Drang-Zorn',
        Foto: 'https://static.wikia.nocookie.net/grimm/images/c/c0/207-Drang-Zorn.png/revision/latest/scale-to-width-down/150?cb=20150609200151.jpg',
        Tipo: 'Tejon',
        Peligrosidad: 'Media',
        Descripcion: 'Se sabe que tienen muy mal genio y se enfurecen con mucha facilidad, siendo propensos a estallidos violentos. Sin embargo, si se enfrentan a un adversario al que saben que no pueden vencer, los Drang-Zorns se refugiarán en guaridas subterráneas que construyeron para casos como estos, y son bastante expertos en construirlas. Sin embargo, algunos Drang-Zorn tienen mejor temperamento que otros y tienen un lado más amable y compasivo.',
        Notas: 'Cuando hacen woge , los Drang-Zorn adquieren pelaje negro en la cara, el cuello y los brazos. Sus rasgos cambian, volviéndose parecidos a los de un tejón, y obtienen dientes afilados. Sus orejas se alargan y son sexualmente dimórficos. Sus manos desarrollan grandes garras adecuadas para cavar. Los machos tienen un woge mucho más severo, les crece pelo en todo el cuerpo, mientras que a las hembras mantienen su cabello normal, les crece pelo en los brazos y las manos y simplemente cambian las características'
    },
    {
        id: 'Cupiditas',
        Nombre: 'Cupiditas',
        Foto: 'https://static.wikia.nocookie.net/grimm/images/e/ed/607-Randy_woged.png/revision/latest/scale-to-width-down/150?cb=20170219182936',
        Tipo: 'Criatura similar a Cupido',
        Peligrosidad: 'Media',
        Descripcion: 'Cuando un Cupiditas woges , su piel se vuelve de un color verde azulado oscuro o azul grisáceo, su cabello se echa hacia atrás y pierde el cabello a los lados de la cabeza, su esclerótica se vuelve negra mientras un borde exterior rojo rodea su brillante iris amarillos, sus orejas se agrandan y se vuelven puntiagudas, sus caninos se vuelven más pronunciados y obtienen dos cuernos cortos y puntiagudos en la frente. Como muchos otros Wesen, pueden concentrar sus woge alrededor de sus ojos, volviéndolos amarillos. Además, obtienen mechones de pelo en las puntas puntiagudas de las orejas, pelo en los nudillos y en la parte posterior de las manos, y una punta de la nariz un poco más pronunciada. Sus uñas también se alargan y adquieren forma de almendra. El pelo de su cabeza continúa hasta la parte posterior de su cuello, teniendo cierta semejanza con una melena.',
        Notas: 'Se sabe que los Cupiditas son criaturas vengativas que pueden guardar rencor durante mucho tiempo. Si alguno de sus seres queridos es agraviado de alguna manera, lo vengará, generalmente haciendo el Amor de Infierno. No les importan mucho las vidas de otras personas fuera de su propia familia y están dispuestos a matar a cualquiera que se interponga en su camino para lograr su propio tipo de justicia vengativa. Al carecer de cualquier destreza física particular en su estado de trabajo, recurren a utilizar su inteligencia y su comportamiento astuto y astuto a su favor.'
        
    },
    {
        id: 'Aswang',
        Nombre: 'Aswang',
        Foto: 'https://static.wikia.nocookie.net/grimm/images/e/ef/314-Aswang.png/revision/latest/scale-to-width-down/150?cb=20140308061645.jpg',
        Tipo: 'Demonio',
        Peligrosidad: 'Alta',
        Descripcion: 'Cuando son woged , los Aswang son criaturas calvas, parecidas a ghouls, con piel gris pálida y nariz de murciélago. Sus ojos plateados y monótonos brillan débilmente en la oscuridad. Las vértebras a lo largo de la espalda se agrandan hasta el punto de formar una cresta notable y poseen colmillos y garras en forma de agujas. Además, cuando hacen woge, sus voces tienen un tono un poco más estridente.',
        Notas: 'Los Aswang son criaturas de la familia demoníaca. Su nombre significa "monstruo de la oscuridad".'

        
    },
    {
        id:'Balam',
        Nombre: 'Balam',
        Foto: 'https://static.wikia.nocookie.net/grimm/images/7/7a/Balam.png/revision/latest/scale-to-width-down/150?cb=20130422044923',
        Tipo: 'Jaguar',
        Peligrosidad: 'Media',
        Descripcion: 'Cuando son woged , a los Balam les crece pelaje sobre la cabeza y el cuerpo, pero como a muchos Wesen, su cabello no se ve afectado. Muestran manchas distintivas en forma de rayas similares a las de un jaguar o un leopardo. El color de su pelaje parece cambiar dependiendo del brillo del entorno',
        Notas: 'Los Balam son criaturas de la familia de los jaguars. Su nombre significa "jaguar de la oscuridad".'
    },
    {
        id:'Fuilcre',
        Nombre: 'Fuilcre',
        Foto: 'https://static.wikia.nocookie.net/grimm/images/4/43/509-Mark_Holloway_woged.png/revision/latest/scale-to-width-down/150?cb=20160213231054.jpg',
        Tipo: 'Buey',
        Peligrosidad: 'Baja',
        Descripcion: 'Cuando Fuilcré woge , su cambio más notable son los dos cuernos que emergen de cada lado de su cabeza, encima y justo detrás de las orejas. Sus cuernos se curvan y giran anteriormente hacia cada extremo, lo que los convierte en armas peligrosas. Su nariz y orejas se vuelven más bovinas, al igual que sus dientes. Sus incisivos, concretamente, también aumentan de tamaño. Les crece pelo en todos los brazos y también les crece una gran cantidad de vello facial, y el pelo en la parte superior de la cabeza también se vuelve más largo, asemejándose a la apariencia de una melena.',
        Notas: 'Fuilcré fue uno de los primeros Wesen en autodomesticarse y cultivar tierras para alimentarse en lugar de cazar Kehrseite . Son hábiles como agricultores y no se les considera Wesen muy violentos, pero son conocidos por sus rituales pasados ​​que involucraban sacrificios humanos. Sin embargo, en los tiempos modernos, la mayoría de los Fuilcré ya no realizan ese tipo de rituales que giraban en torno a las estrellas y las constelaciones. También son de naturaleza deliberada, directa y honesta.'
    },
    {
        id:'Taweret',
        Nombre: 'Taweret',
        Foto: 'https://static.wikia.nocookie.net/grimm/images/d/d7/605-Mandy_woged.png/revision/latest/scale-to-width-down/150?cb=20170211004514',
        Tipo: 'Hipopotamo',
        Peligrosidad: 'Baja',
        Descripcion:'Basado en el único Taweret visto hasta ahora, pueden tener una tendencia a ser corpulentos mientras están en su forma humana. Cuando hacen woge , Taweret crece varios pies de altura y adquiere una cabeza parecida a la de un hipopótamo. No pierden el pelo de la cabeza en sus formas woged. Su boca es bastante grande, capaz de albergar en ella la cabeza de un hombre adulto.',
        Notas:'Taweret parece ser una especie relajada y tranquila. No son inherentemente beligerantes, pero se defenderán cuando se les amenace, incluso si eso significa matar a su agresor. Las mujeres son seres sociales a quienes les gustan mucho los gestos caballerosos.',

    },
    {
        id:'Heftigauroch',
        Nombre: 'Heftigauroch',
        Foto: 'https://static.wikia.nocookie.net/grimm/images/4/49/403-Clay%27s_mom_woged.jpg/revision/latest/scale-to-width-down/150?cb=20141113013513.jpg',
        Tipo: 'Toro',
        Peligrosidad: 'Baja',
        Descripcion: 'Cuando woge , los Heftigaurochs parecen similares a Taureus-Armenta . Las principales diferencias entre ellos son el adelgazamiento del cabello que se encuentra en los Heftigaurochs y un conjunto de cuernos menos impresionante. Los Heftigaurochs tienen cabezas duras y manos fuertes, lo que los convierte en grandes luchadores a pesar de que no está en su naturaleza luchar. Como muchos otros Wesen, los Heftigaurochs pueden enfocar su woge sólo en sus ojos, que brillan de color amarillo. Los heftigaurochs frecuentemente abren sus ojos cuando están en estado de ira.',
        Notas: 'Los heftigaurochs suelen ser tranquilos y pacifistas. Los Heftigaurochs que se ven atrapados en deportes violentos como el boxeo se muestran casi indiferentes al respecto. Cuando se les empuja más allá de su límite, los Heftigaurochs se vuelven violentos. Una vez que se enfurecen, les lleva algún tiempo volver a sus personalidades normales.'
    },
    {
        id:'Kitsune',
        Nombre: 'Kitsune',
        Foto: 'https://static.wikia.nocookie.net/grimm/images/2/25/517-Jin_Akagi_woged.png/revision/latest/scale-to-width-down/150?cb=20160420165011.jpg',
        Tipo: 'Zorro',
        Peligrosidad: 'Baja',
        Descripcion: 'Al woge , los Kitsune obtienen un pelaje largo y blanco, ojos azules brillantes y brillantes, dos orejas alargadas y puntiagudas y una nariz y un hocico parecidos a los de un zorro. Sus manos, sin embargo, no se ven afectadas por su transformación. Obtienen un filtro negro que se extiende hasta el labio superior, que también se vuelve negro junto con el labio inferior, en contraste con su pelaje blanco.',
        Notas: 'Los kitsune son Wesen muy reservados; sin embargo, si matan a un miembro de su familia, se enfurecerá y puede ser propenso a guardar rencor en ese caso. Sus familias tienden a ser muy unidas entre sí. En los tiempos modernos, no están de acuerdo con métodos de venganza más draconianos, como aquellos que incluyen el asesinato o son practicados por los Inugami , Wesen que están atados en servidumbre por un honor y una tradición estilo samurái a las familias Kitsune si su vida es salvada por un Kitsune.',

    },
    {
      id:'Krampus',
      Nombre: 'Krampus',
      Foto: 'https://static.wikia.nocookie.net/grimm/images/c/c7/308-Krampus.png/revision/latest/scale-to-width-down/150?cb=20131214080817.jpg',
      Tipo: 'Anti-Santa',
      Peligrosidad: 'Media',
      Descripcion:'Cuando es atacado , Krampus elige usar un traje de Papá Noel y tiene dientes afilados, cuernos rizados, garras y una lengua bífida roja y llameante.A pesar de su apariencia única y su pesado atuendo, es capaz de mantener altos niveles de sigilo, ya que ninguna de sus víctimas era consciente de su presencia antes de que hablara, y podía desaparecer sin esfuerzo dentro de una ciudad a pesar de no poder disfrazarse de humano.',
      Notas:'Incluso entre los Wesen, Krampus es único. No es consciente de que es Krampus o incluso Wesen. Sólo puede trabajar desde el primero de diciembre hasta el veintiuno, cuando entra en un estado de trabajo constante tan fijo que ni siquiera la pérdida del conocimiento puede hacerle revertir. Es durante este tiempo que se puede decir que Krampus realmente existe.',

    },
   
    
];





    function eliminarFilaPorNumero() {
        const numeroFila = prompt("Ingrese el número de la fila que desea eliminar:");
      
        if (numeroFila !== null) {
          const filaIndex = parseInt(numeroFila, 10);
      
          if (!isNaN(filaIndex)) {
            const tabla = document.querySelector(".tableWesenCompleted");
            const filas = tabla.getElementsByTagName("tr");
      
            if (filaIndex >= 1 && filaIndex <= filas.length) {
              tabla.deleteRow(filaIndex);
            } else {
              alert("Número de fila no válido. Por favor, ingrese un número entre 1 y " + filas.length);
            }
          } else {
            alert("Por favor, ingrese un número válido.");
          }
        }
      }


   
   
